//
//  EventItems.swift
//  Reviews
//
//  Created by MacStudent on 2018-08-13.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class EventItems{
    static var eventImages : [String] = ["Event1", "Event2", "Event3", "Event4"]
    static var eventTitle : [String] = ["Event1", "Event2", "Event3", "Event4"]
    static var eventDate : [String] = ["15/08/2018", "21/09/2018", "31/12/2018", "04/09/2018"]
    static var eventLocation : [String] = ["Toronto", "Vancouver", "London", "Sydney"]
}
