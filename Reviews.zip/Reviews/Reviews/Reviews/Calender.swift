//
//  Calender.swift
//  Reviews
//
//  Created by MacStudent on 2018-08-16.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import EventKit
import EventKitUI

class Calender: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let eventStore = EKEventStore()
        let formatter = DateFormatter()
    
        
        eventStore.requestAccess( to: EKEntityType.event, completion:{(granted, error) in

            if (granted) && (error == nil) {


                let event = EKEvent(eventStore: eventStore)

                event.title = "Bhangra Event"
                formatter.dateFormat = "yyyy mm dd"
                formatter.timeZone = Calendar.current.timeZone
                formatter.locale = Calendar.current.locale

                //event.startDate = Date(timeIntervalSinceNow: TimeInterval())

                event.startDate = formatter.date(from: "2018 11 01")!
                event.endDate = formatter.date(from: "2018 11 02")!
                event.notes = "Yeah!!!"
                event.calendar = eventStore.defaultCalendarForNewEvents

                var event_id = ""
                do{
                    try eventStore.save(event, span: .thisEvent)
                    event_id = event.eventIdentifier
                }
                catch let error as NSError {
                    print("json error: \(error.localizedDescription)")
                }

                if(event_id != ""){
                    print("event added !")
                }
            }
        })
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension Calender: EKEventEditViewDelegate {
    
    func eventEditViewController(_ controller: EKEventEditViewController, didCompleteWith action: EKEventEditViewAction) {
        controller.dismiss(animated: true)
    }
}
