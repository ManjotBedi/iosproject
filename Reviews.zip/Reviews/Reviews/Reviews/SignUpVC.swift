//
//  SignUpVC.swift
//  Reviews
//
//  Created by MacStudent on 2018-08-18.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class SignUpVC: UIViewController {

    @IBOutlet weak var txtCPass: UITextField!
    @IBOutlet weak var txtPass: UITextField!
    @IBOutlet weak var txtEmlAdd: UITextField!
    @IBOutlet weak var txtName: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func btnSign(_ sender: UIButton) {
        
        var data : String = txtName.text!
        data += "\n" + txtEmlAdd.text!
        data += "\n" + txtPass.text!
        data += "\n" + txtCPass.text!
        
        let infoAlert = UIAlertController(title: "Confirm Details", message: data, preferredStyle: .alert)
        
        if txtPass.text != txtCPass.text{
            infoAlert.message = " Both password must match "
        }else{
            infoAlert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: {_ in self.displayHomeVC()}))
        }
        
        infoAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(infoAlert,animated: true,completion: nil)
        
    }
    
    func displayHomeVC()
    {
        let newUser = User(txtName.text!,
                           txtEmlAdd.text!, txtPass.text!)
        
        if User.addUser(newUser: newUser){
            let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let SignUpVC = mainSB.instantiateViewController(withIdentifier: "LoginScene")
            navigationController?.pushViewController(SignUpVC, animated: true)
        }else{
            let infoAlert = UIAlertController(title: "Unsuccessful", message: "Account Creation Unsuccessful", preferredStyle: .alert)
            infoAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            self.present(infoAlert, animated: true, completion: nil)
        }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    }
}
