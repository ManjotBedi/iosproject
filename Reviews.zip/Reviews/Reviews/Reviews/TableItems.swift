//
//  TableItems.swift
//  Reviews
//
//  Created by MacStudent on 2018-08-10.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Logo{
    static var logo: [String] = ["logo","bg"]
}

class TableItems{
    static var titles: [String] = ["Events", "Popular Dates"]
    static var subTitles: [String] = ["Time is not yours", "Be Everywhere"]
    static var images: [String] = ["Events","Calendar"]
}
